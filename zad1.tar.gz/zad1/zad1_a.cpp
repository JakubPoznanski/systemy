// Jakub Poznanski
#include "display.h"
int main()
{
    display();
    return 0;
}
