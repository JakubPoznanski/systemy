Autor: Jakub Poznański 
Data: 26.03.2023
---------------------------OPIS PROGRAMÓW ZAD2---------------------------






-----------------------Jak uruchomić programy?---------------------------

1.          "make run" 
        -kompiluje zad2
        -kompiluje display
        -uruchamia program zad2 (./zad2 ./display display) 
        podając argumenty wywołania 


2.polecenie "make clean" Usuwa wszystkie skompilowane pliki 

3.polecenie "make tar" służy do archiwizacji
---------------------------------------------------------------------------